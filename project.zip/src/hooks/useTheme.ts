export { useTheme as default } from 'styled-components/native';
