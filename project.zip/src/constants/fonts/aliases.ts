export const FONT_ALIASES = {} as const;
