declare module 'react-native-vector-icons/*' {
  import { ComponentType } from 'react';
  const Icon: ComponentType<Record<string, unknown>>;
  export default Icon;
}

