declare module '*.ttf' {
  const value: number;
  export default value;
}
