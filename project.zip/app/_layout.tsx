export { default } from 'src/screens/root-layout';
