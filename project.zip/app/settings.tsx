export { default } from 'src/screens/settings';
