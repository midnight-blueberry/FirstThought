export { default } from 'src/screens/home-page';
